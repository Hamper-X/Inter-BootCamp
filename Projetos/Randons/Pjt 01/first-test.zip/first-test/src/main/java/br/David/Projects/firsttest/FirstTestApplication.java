package br.David.Projects.firsttest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstTestApplication.class, args);
	}

}
