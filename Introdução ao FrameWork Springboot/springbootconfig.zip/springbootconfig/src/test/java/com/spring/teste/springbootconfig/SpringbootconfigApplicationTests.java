package com.spring.teste.springbootconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootconfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
